import xbmcaddon

MainBase = 'http://tvbstreamz.net/addonmenus/home.xml'
addon = xbmcaddon.Addon('plugin.video.tvbvod')